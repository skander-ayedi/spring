package com.example.universityappl.model;

public enum ERole {
    ROLE_ETUDIANT,
    ROLE_ENSEIGNANT,
    ROLE_ADMIN
}